import React from 'react'

const third = () => {
  return (
    <div>third</div>
  )
}

export default third