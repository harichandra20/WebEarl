import React from 'react'

const Body = () => {
  return (
    <div className='body'>
       <div className="left2">
            <div className='innerleft'>
                 <h1>Aenean Facilisis viate</h1>
                 <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptate iure a recusandae eaque, officia accusamus iste! Consequatur impedit to</p>
                 <div><button>wright us</button></div>
            </div>
       </div>
       <div className="right2">
              <img src='https://th.bing.com/th/id/OIP.18TX1vFE7j5gzBTUm_OinAHaDp?w=294&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7'style={{width:"500px"}}></img> 
       </div> 
    </div>
  )
}

export default Body