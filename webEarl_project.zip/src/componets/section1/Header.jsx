import React from 'react';
import "./Section.css";

const Header = () => {
  return (
    <div className='header'>
      <div className="container">
        <div className="left">Agency</div>
        <div className="right">
          <ul className='nav-list'>
            <li className='nav-item'>Service</li>
            <li className='nav-item'>Our Values</li>
            <li className='nav-item'>Case Studies</li>
            <li className='nav-item'>Blog</li>
            <li className='nav-item'>Inner Pages</li>
            <li className='nav-item'>
              <button>Login</button>
            </li>
            <li className='nav-item'>
              <button>Register</button>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Header;
