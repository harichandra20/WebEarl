import React from 'react'

const footer = () => {
  return (
    <div className='footer'>
      <div>
         <h1>bussness solution</h1>
          <p>Lorem ipsum dolor sit amet.</p>
        </div>
        <div>
        <h1>free project quote</h1>
        <p>Lorem ipsum dolor sit amet.</p>
      </div>
      <div>
      <h1>nulla lobortis</h1>
      <p>Lorem ipsum dolor sit amet.</p>
      </div>
    </div>
  )
}

export default footer